<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('global.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo $__env->yieldContent('links'); ?>
    <link rel="stylesheet" href="css/homepage.css">
</head>

<body>
    <?php echo $__env->yieldContent('header'); ?>

    <div class="wrapper">
        <div class="left-wrap">
            <div class="account">
                <div class="panel">
                    <img src="/media/uploads/profile/<?php echo e(\App\System::fixProfileImage($user_data['image'])); ?>" alt="Profile Image">
                </div>

                <div class="stats">
                    <p class="name"><?php echo e($user_data['username']); ?></p>

                    <div class="stats-wrap">
                        <div class="item">
                            <a href="/<?php echo e(Auth::user()->username); ?>" class="statistic-name">Posts</a>
                            <div class="value"><?php echo e(count(\App\System::getPosts(Auth::user()->id, true))); ?></div>
                        </div>
                        <div class="item">
                            <a class="statistic-name">Follower</a>
                            <div class="value">N/A</div>
                        </div>
                        <div class="item">
                            <a class="statistic-name">Follows</a>
                            <div class="value">N/A</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="google-ad-m" style="background-image: url('/media/static/google-ad.png')"></div>
        </div>

        <div class="center-wrap">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post post-resizable" data-route="<?php echo e($post->type); ?>/<?php echo e($post->route); ?>">
                <div class="account">
                    <div class="profile-image">
                        <img src="/media/uploads/profile/<?php echo e(\App\System::getProfileImageByName(\App\System::getUserById($post->author)->username)); ?>" alt="Image">
                    </div>
                    <div class="user-info">
                        <a href="/<?php echo e(\App\System::getUserById($post->author)->username); ?>" class="username"><?php echo e(\App\System::getUserById($post->author)->username); ?></a>
                        <div class="date"><?php echo e(\App\System::toDateFormatWithFormatted($post->created_at, true)); ?></div>
                    </div>

                    <div class="comment-wrap">
                        <div class="comment"><?php echo e(substr(trim($post->comment), 0, 70)); ?></div>
                    </div>
                </div>

                <div class="img-holder">
                    <img src="media/uploads/12d345f245d/14.02.18_17-23-46.png" alt="">
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="right-wrap">
            <div class="title">Freunde finden</div>

            <div class="suggested-users">
                <?php $__currentLoopData = $users_suggested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->username != Auth::user()->username): ?>
                <div class="user-profile">
                    <a href="/<?php echo e($user->username); ?>"><img src="/media/uploads/profile/<?php echo e(\App\System::fixProfileImage($user->image)); ?>" alt="Profile Image"></a>
                    <div class="user-data">
                        <a href="/<?php echo e($user->username); ?>" class="name"><?php echo e($user->username); ?></a>
                        <div class="follow-btn">Follow</div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
