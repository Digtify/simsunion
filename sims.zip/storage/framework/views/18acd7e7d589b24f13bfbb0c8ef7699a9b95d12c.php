<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('global.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo $__env->yieldContent('links'); ?>
    <link rel="stylesheet" href="css/auth.css">
</head>

<body>
    <?php echo $__env->yieldContent('header'); ?>
    <div class="sub-header">
        <div class="mode" id="auth-mode" data-mode="<?php echo e($mode); ?>"><?php echo e(trans('auth.' . $mode)); ?></div>
    </div>

    
    <div class="form-wrapper">
        <form action="" method="post" class="form">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="error">
                        <p class="error-code"><?php echo e($error); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php echo csrf_field(); ?>
            <?php if($status == '403'): ?>
                <div class="error">
                    <p class="error-code"><?php echo e(trans('auth.errors.logged-in')); ?></p>
                </div>
            <?php endif; ?>
            <?php if($status == '505'): ?>
                <div class="error">
                    <p class="error-code"><?php echo e(trans('auth.errors.failed')); ?></p>
                </div>
            <?php endif; ?>
            <label for="mail" class="support"><?php echo e(trans('auth.input.mail')); ?></label>
            <input type="text" class="input<?php echo e($errors->has('mail') ? ' input-error' : ''); ?>" id="mail" name="mail" value="" placeholder="<?php echo e(trans('auth.input.mail')); ?>" value="<?php echo e(old('mail')); ?>">
            <small><?php echo e($errors->first('mail')); ?></small>
            <?php if($mode == 'register'): ?>
            <label for="username" class="support"><?php echo e(trans('auth.input.name')); ?></label>
            <input type="text" class="input" id="username" name="username" value="" placeholder="<?php echo e(trans('auth.input.name')); ?>">
            <?php endif; ?>
            <label for="password" class="support"><?php echo e(trans('auth.input.password')); ?></label>
            <input type="password" class="input" id="password" name="password" value="" placeholder="<?php echo e(trans('auth.input.password')); ?>">
            <?php if($mode == 'register'): ?>
            <label for="password_repeat" class="support"><?php echo e(trans('auth.input.password-repeat')); ?></label>
            <input type="password" class="input" id="password_repeat" name="password_repeat" value="" placeholder="<?php echo e(trans('auth.input.password-repeat')); ?>">
            <?php endif; ?>
            <input type="submit" class="submit" id="submit-auth" value="<?php echo e(trans('auth.' . $mode)); ?>">
        </form>
    </div>

    <?php if($mode == 'login'): ?>
    <div class="note"><?php echo e(trans('auth.note-login')); ?> <a href="/register"><?php echo e(trans('auth.note-login-a')); ?></a></div>
    <?php else: ?>
    <div class="note"><?php echo e(trans('auth.note-register')); ?> <a href="/login"><?php echo e(trans('auth.note-register-a')); ?></a></div>
    <?php endif; ?>

    <script src="js/jquery.min.js"></script>
    <script src="js/auth.js"></script>
</body>
</html>