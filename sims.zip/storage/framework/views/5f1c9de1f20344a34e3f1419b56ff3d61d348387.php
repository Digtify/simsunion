<html>
<head>
    <?php echo $__env->make('global.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>404 Not Found | <?php echo e(config('app.brand')); ?></title>
    <?php echo $__env->yieldContent('links'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('header'); ?>

    <div class="error-section">
        <div class="center">
            <p class="error-code">404</p>
            <p class="error-code-sub">Page Not found</p>
        </div>
    </div>
    <script src="/js/jquery.min.js"></script>
    <script src="/js/app.js"></script>
</body>
</html>