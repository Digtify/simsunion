$('#account_dropdown').click(function () {
    $('#dropdown-account-wrap').toggleClass('active');
});

